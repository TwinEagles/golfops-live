(function () {
  const REPORT_EVENT = "golfops-schedulepop-report";
  const PTO_COMMAND_EVENT = "golfops-schedulepop-pto-command";
  const PTO_DATA_EVENT = "golfops-schedulepop-pto-data";
  const SCHEDULE_COMMAND_EVENT = "golfops-schedulepop-schedule-command";
  const SCHEDULE_DATA_EVENT = "golfops-schedulepop-schedule-data";
  const originalFetch = window.fetch;
  let locationId = null;
  let schedulePopAuthorization = null;
  let latestScheduleRange = null;

  function parseUrl(value) {
    try { return new URL(String(value), window.location.href); } catch { return null; }
  }

  function learnContext(value) {
    const url = parseUrl(value);
    if (!url || url.hostname !== "api.schedulepop.com") return url;
    const match = url.pathname.match(/\/locations\/(\d+)/);
    if (match) locationId = Number(match[1]);
    return url;
  }

  function rememberAuthorization(headers) {
    if (!headers) return;

    let value = null;
    try {
      if (headers instanceof Headers) {
        value = headers.get("authorization");
      } else if (Array.isArray(headers)) {
        const entry = headers.find(([name]) => String(name).toLowerCase() === "authorization");
        value = entry?.[1] || null;
      } else if (typeof headers === "object") {
        const key = Object.keys(headers).find((name) => name.toLowerCase() === "authorization");
        value = key ? headers[key] : null;
      }
    } catch {
      value = null;
    }

    if (typeof value === "string" && /^Bearer\s+\S+/i.test(value.trim())) {
      schedulePopAuthorization = value.trim();
    }
  }

  function rememberScheduleRange(url, body) {
    if (
      !url ||
      url.hostname !== "api.schedulepop.com" ||
      !url.pathname.includes("/scheduleData") ||
      url.searchParams.get("scheduleDataTypes") !== "staffView"
    ) return;

    try {
      const value = typeof body === "string" ? JSON.parse(body) : body;
      if (
        /^\d{4}-\d{2}-\d{2}$/.test(String(value?.start || "")) &&
        /^\d{4}-\d{2}-\d{2}$/.test(String(value?.end || ""))
      ) {
        latestScheduleRange = { dateStart: value.start, dateEnd: value.end };
      }
    } catch { /* The content script can still derive the visible week from the URL. */ }
  }

  function announceReport(value) {
    const url = learnContext(value);
    if (url?.hostname === "api.schedulepop.com" && url.pathname.includes("/printableSchedule")) {
      window.dispatchEvent(new CustomEvent(REPORT_EVENT, { detail: url.toString() }));
    }
  }

  function sanitizeEmployee(value) {
    if (!value || typeof value !== "object") return null;
    const duties = Array.isArray(value.userDuties) ? value.userDuties.map((duty) => ({
      id: duty?.id, duty: duty?.duty, name: duty?.name,
      disabled: duty?.disabled, activeDuty: duty?.activeDuty,
    })) : [];
    const zones = Array.isArray(value.userZones) ? value.userZones.map((zone) => ({
      id: zone?.id, zone: zone?.zone, zoneName: zone?.zoneName, enabled: zone?.enabled,
    })) : [];
    return {
      id: Number(value.id), firstname: value.firstname || "", lastname: value.lastname || "",
      email: value.email || "", userStatusTypeName: value.userStatusTypeName || "",
      userDuties: duties, userZones: zones,
    };
  }

  function sanitizePto(value) {
    if (!value || typeof value !== "object") return null;
    return {
      id: Number(value.id), user: Number(value.user), firstname: value.firstname || "",
      lastname: value.lastname || "", start: value.start || "", end: value.end || "",
      allDay: value.allDay !== false, approved: value.approved === true,
      isDeleted: value.isDeleted === true, status: value.status || "PTO",
      managerNote: value.managerNote || null, createDatetime: value.createDatetime || null,
      updateDatetime: value.updateDatetime || null,
    };
  }

  function emitPto(detail) {
    window.dispatchEvent(new CustomEvent(PTO_DATA_EVENT, { detail }));
  }

  function emitSchedule(detail) {
    window.dispatchEvent(new CustomEvent(SCHEDULE_DATA_EVENT, { detail }));
  }

  async function inspectPtoMutation(url, method, response) {
    if (!url || url.hostname !== "api.schedulepop.com") return;
    if (url.pathname.includes("/approveTimeOff") && response.ok) {
      try {
        const body = await response.clone().json();
        const request = sanitizePto(body);
        const employee = sanitizeEmployee(body?.userObj);
        if (request?.id) {
          emitPto({ sourceMode: "delta", action: "upsert", locationId,
            employees: employee ? [employee] : [], requests: [request], complete: false });
        }
      } catch { /* Manual full sync remains available if SchedulePop changes this response. */ }
      return;
    }

    const deleteMatch = url.pathname.match(/\/locations\/(\d+)\/users\/(\d+)\/availabilities\/(\d+)$/);
    if (method === "DELETE" && deleteMatch && response.ok) {
      const today = new Date().toISOString().slice(0, 10);
      emitPto({
        sourceMode: "delta", action: "delete", locationId: Number(deleteMatch[1]), employees: [],
        requests: [{ id: Number(deleteMatch[3]), user: Number(deleteMatch[2]),
          start: `${today} 00:00:00`, end: `${today} 23:59:59` }], complete: false,
      });
    }
  }

  function asArray(value) {
    if (Array.isArray(value)) return value;
    if (Array.isArray(value?.data)) return value.data;
    if (Array.isArray(value?.items)) return value.items;
    if (Array.isArray(value?.results)) return value.results;
    return [];
  }

  async function fetchJson(url) {
    if (!schedulePopAuthorization) {
      throw new Error(
        "SchedulePop authorization was not detected. Refresh the SchedulePop page, wait for the dashboard to load, and try again."
      );
    }

    const response = await originalFetch.call(window, url, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      headers: {
        Accept: "application/json",
        Authorization: schedulePopAuthorization,
      },
    });
    if (!response.ok) throw new Error(`SchedulePop returned ${response.status}.`);
    return response.json();
  }

  async function mapWithConcurrency(values, limit, mapper) {
    const results = new Array(values.length);
    let next = 0;
    async function worker() {
      while (next < values.length) {
        const index = next++;
        results[index] = await mapper(values[index], index);
      }
    }
    await Promise.all(Array.from({ length: Math.min(limit, values.length) }, worker));
    return results;
  }

  async function fullPtoSync(detail) {
    const requestId = detail?.requestId || null;
    try {
      if (!locationId) throw new Error("Open the SchedulePop Dashboard or Users page once, then try TEAM PTO again.");
      if (!schedulePopAuthorization) {
        throw new Error(
          "SchedulePop authorization was not detected. Refresh the SchedulePop page, wait for the dashboard to load, and try again."
        );
      }
      const dateStart = String(latestScheduleRange?.dateStart || detail?.dateStart || "");
      const dateEnd = String(latestScheduleRange?.dateEnd || detail?.dateEnd || "");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStart) || !/^\d{4}-\d{2}-\d{2}$/.test(dateEnd)) {
        throw new Error("The TEAM PTO date range is invalid.");
      }

      emitPto({
        requestId,
        collectInExtension: true,
        authorization: schedulePopAuthorization,
        locationId,
        dateStart,
        dateEnd,
      });
    } catch (error) {
      emitPto({ requestId, error: error instanceof Error ? error.message : "Unable to collect SchedulePop PTO." });
    }
  }

  function fullScheduleSync(detail) {
    const requestId = detail?.requestId || null;
    try {
      if (!locationId) {
        throw new Error("Open the SchedulePop Schedule page and wait for it to load, then try again.");
      }
      if (!schedulePopAuthorization) {
        throw new Error(
          "SchedulePop authorization was not detected. Refresh the SchedulePop page, wait for the schedule to load, and try again."
        );
      }
      const dateStart = String(detail?.dateStart || "");
      const dateEnd = String(detail?.dateEnd || "");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStart) || !/^\d{4}-\d{2}-\d{2}$/.test(dateEnd)) {
        throw new Error("The displayed SchedulePop week could not be identified.");
      }

      emitSchedule({
        requestId,
        collectInExtension: true,
        authorization: schedulePopAuthorization,
        locationId,
        dateStart,
        dateEnd,
      });
    } catch (error) {
      emitSchedule({
        requestId,
        error: error instanceof Error ? error.message : "Unable to collect the SchedulePop schedule.",
      });
    }
  }

  const originalOpen = window.open;
  window.open = function (url, ...args) {
    announceReport(url);
    return originalOpen.call(window, url, ...args);
  };

  window.fetch = function (input, init) {
    const value = typeof input === "string" ? input : input?.url;
    const url = learnContext(value);
    if (url?.hostname === "api.schedulepop.com") {
      rememberAuthorization(init?.headers);
      if (typeof input === "object") rememberAuthorization(input?.headers);
      rememberScheduleRange(url, init?.body);
    }
    announceReport(value);
    const method = String(init?.method || (typeof input === "object" ? input?.method : "GET") || "GET").toUpperCase();
    const promise = originalFetch.call(this, input, init);
    promise.then((response) => inspectPtoMutation(url, method, response)).catch(() => {});
    return promise;
  };

  const originalXhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...args) {
    this.__golfOpsSchedulePopUrl = learnContext(url);
    announceReport(url);
    return originalXhrOpen.call(this, method, url, ...args);
  };

  const originalXhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    rememberScheduleRange(this.__golfOpsSchedulePopUrl, body);
    return originalXhrSend.call(this, body);
  };

  const originalXhrSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (
      this.__golfOpsSchedulePopUrl?.hostname === "api.schedulepop.com" &&
      String(name).toLowerCase() === "authorization"
    ) {
      rememberAuthorization({ Authorization: value });
    }
    return originalXhrSetRequestHeader.call(this, name, value);
  };

  document.addEventListener("click", (event) => {
    const target = event.target instanceof Element ? event.target.closest("a[href]") : null;
    if (target) announceReport(target.href);
  }, true);

  window.addEventListener(PTO_COMMAND_EVENT, (event) => fullPtoSync(event.detail));
  window.addEventListener(SCHEDULE_COMMAND_EVENT, (event) => fullScheduleSync(event.detail));
})();
