function isForeTeesTeeSheetPage() {
  const url = new URL(window.location.href);

  const isProshopSheet =
    url.pathname.toLowerCase().includes("/servlet/proshop_sheet");

  const isPrintReport =
    url.searchParams.get("print") === "report";

  const isAllCourses =
    url.searchParams.get("course") === "-ALL-";

  return isProshopSheet && isPrintReport && isAllCourses;
}

function showStatus(message, type = "normal") {
  let box = document.getElementById("cart-barn-live-2-status");

  if (!box) {
    box = document.createElement("div");
    box.id = "cart-barn-live-2-status";

    Object.assign(box.style, {
      position: "fixed",
      right: "20px",
      bottom: "20px",
      zIndex: "999999",
      padding: "14px 18px",
      borderRadius: "10px",
      fontFamily: "Arial, sans-serif",
      fontSize: "14px",
      fontWeight: "600",
      color: "white",
      boxShadow: "0 4px 16px rgba(0,0,0,0.2)"
    });

    document.body.appendChild(box);
  }

  box.textContent = message;

  if (type === "success") {
    box.style.background = "#15803d";
  } else if (type === "error") {
    box.style.background = "#b91c1c";
  } else {
    box.style.background = "#334155";
  }
}

function sendTeeSheet() {
  if (!isForeTeesTeeSheetPage()) {
    return;
  }

  showStatus("Sending to Cart Barn Live 2...");

  chrome.runtime.sendMessage(
    {
      type: "SEND_TEE_SHEET",
      payload: {
        html: document.documentElement.outerHTML,
        source: "A",
        url: window.location.href,
        timezone: "America/New_York"
      }
    },
    (response) => {
      if (chrome.runtime.lastError) {
        const errorMessage =
          chrome.runtime.lastError.message ||
          "Unknown extension error.";

        console.error(
          "Cart Barn Live 2 extension error:",
          errorMessage
        );

        showStatus(
          `Extension error: ${errorMessage}`,
          "error"
        );

        return;
      }

      if (response?.ok) {
        const changes =
          typeof response.changesDetected === "number"
            ? ` • ${response.changesDetected} changes`
            : "";

        showStatus(
          `Import Successful — ${response.teeTimesFound} tee times / ${response.playersFound} players${changes}`,
          "success"
        );
      } else {
        console.error(
          "Cart Barn Live 2 import response:",
          response
        );

        showStatus(
          response?.error || "Import failed.",
          "error"
        );
      }
    }
  );
}

setTimeout(sendTeeSheet, 1500);