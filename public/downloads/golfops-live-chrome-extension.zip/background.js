const APP_URL = "http://localhost:3000";

const STORAGE_KEYS = [
  "access_token",
  "refresh_token",
  "expires_at",
  "user_email"
];

function getStoredSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      STORAGE_KEYS,
      (result) => {
        resolve(result || {});
      }
    );
  });
}

function saveSession(session) {
  return new Promise((resolve) => {
    chrome.storage.local.set(
      {
        access_token:
          session.access_token,

        refresh_token:
          session.refresh_token,

        expires_at:
          session.expires_at,

        user_email:
          session.user_email
      },
      resolve
    );
  });
}

function clearSession() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(
      STORAGE_KEYS,
      resolve
    );
  });
}

function tokenExpiresSoon(expiresAt) {
  if (!expiresAt) {
    return true;
  }

  const expiresAtMs =
    Number(expiresAt) * 1000;

  if (
    Number.isNaN(
      expiresAtMs
    )
  ) {
    return true;
  }

  const fiveMinutes =
    5 * 60 * 1000;

  return (
    Date.now() >=
    expiresAtMs -
      fiveMinutes
  );
}

async function refreshSession(
  refreshToken
) {
  if (!refreshToken) {
    throw new Error(
      "Extension is not signed in."
    );
  }

  const response =
    await fetch(
      `${APP_URL}/api/extension/refresh`,
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json"
        },
        body: JSON.stringify({
          refresh_token:
            refreshToken
        })
      }
    );

  let result = null;

  try {
    result =
      await response.json();
  } catch {
    throw new Error(
      `Session refresh failed (${response.status}).`
    );
  }

  if (
    !response.ok ||
    !result?.access_token ||
    !result?.refresh_token
  ) {
    throw new Error(
      result?.error ||
        "Unable to refresh extension session."
    );
  }

  await saveSession({
    access_token:
      result.access_token,

    refresh_token:
      result.refresh_token,

    expires_at:
      result.expires_at,

    user_email:
      result.user_email
  });

  return result;
}

async function getValidAccessToken() {
  let session =
    await getStoredSession();

  if (!session.refresh_token) {
    throw new Error(
      "Cart Barn Live 2 extension is not signed in."
    );
  }

  /*
    Refresh proactively if the token
    is expired or will expire within
    five minutes.
  */

  if (
    !session.access_token ||
    tokenExpiresSoon(
      session.expires_at
    )
  ) {
    session =
      await refreshSession(
        session.refresh_token
      );
  }

  return {
    accessToken:
      session.access_token,

    refreshToken:
      session.refresh_token
  };
}

async function sendImportRequest(
  payload,
  accessToken
) {
  return fetch(
    `${APP_URL}/api/import/extension`,
    {
      method: "POST",

      headers: {
        "Content-Type":
          "application/json",

        Authorization:
          `Bearer ${accessToken}`
      },

      body: JSON.stringify(
        payload
      )
    }
  );
}

async function parseResponse(
  response
) {
  const contentType =
    response.headers.get(
      "content-type"
    ) || "";

  if (
    contentType.includes(
      "application/json"
    )
  ) {
    return response.json();
  }

  const text =
    await response.text();

  return {
    error:
      text ||
      `Request failed (${response.status}).`
  };
}

async function sendTeeSheet(
  payload
) {
  let session =
    await getStoredSession();

  if (
    !session.refresh_token
  ) {
    return {
      ok: false,
      error:
        "Cart Barn Live 2 extension is not signed in. Open Extension Options and sign in."
    };
  }

  /*
    First obtain a token that should
    still be valid.
  */

  let accessToken;

  try {
    const validSession =
      await getValidAccessToken();

    accessToken =
      validSession.accessToken;

    session =
      await getStoredSession();
  } catch (error) {
    console.error(
      "Unable to obtain extension session:",
      error
    );

    return {
      ok: false,
      error:
        error instanceof Error
          ? error.message
          : "Unable to refresh extension login."
    };
  }

  /*
    First import attempt.
  */

  let response =
    await sendImportRequest(
      payload,
      accessToken
    );

  /*
    If Supabase rejects the token,
    refresh once and retry.
  */

  if (
    response.status === 401
  ) {
    try {
      const refreshed =
        await refreshSession(
          session.refresh_token
        );

      response =
        await sendImportRequest(
          payload,
          refreshed.access_token
        );
    } catch (error) {
      console.error(
        "Extension automatic login refresh failed:",
        error
      );

      await clearSession();

      return {
        ok: false,
        error:
          "Your Cart Barn Live 2 extension session expired. Please sign in again."
      };
    }
  }

  const result =
    await parseResponse(
      response
    );

  if (!response.ok) {
    return {
      ok: false,
      error:
        result?.error ||
        `Import failed (${response.status}).`
    };
  }

  return {
    ok: true,
    ...result
  };
}

chrome.runtime.onMessage.addListener(
  (
    message,
    sender,
    sendResponse
  ) => {
    if (
      message?.type ===
      "SEND_TEE_SHEET"
    ) {
      sendTeeSheet(
        message.payload
      )
        .then(
          sendResponse
        )
        .catch(
          (error) => {
            console.error(
              "Cart Barn Live 2 background error:",
              error
            );

            sendResponse({
              ok: false,
              error:
                error instanceof Error
                  ? error.message
                  : "Unknown extension error."
            });
          }
        );

      return true;
    }

    if (
      message?.type ===
      "CHECK_AUTH"
    ) {
      getStoredSession()
        .then(
          (session) => {
            sendResponse({
              ok: true,

              signedIn:
                Boolean(
                  session.refresh_token
                ),

              user_email:
                session.user_email ||
                null,

              expires_at:
                session.expires_at ||
                null
            });
          }
        );

      return true;
    }

    return false;
  }
);