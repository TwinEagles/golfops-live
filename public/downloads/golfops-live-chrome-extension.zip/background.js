const APP_URL =
  "https://golfops-live.vercel.app";

const STORAGE_KEYS = [
  "access_token",
  "refresh_token",
  "expires_at",
  "user_email"
];

function getStoredSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      STORAGE_KEYS,
      (result) =>
        resolve(result || {})
    );
  });
}

function saveSession(session) {
  return new Promise((resolve) => {
    chrome.storage.local.set(
      {
        access_token:
          session.access_token,

        refresh_token:
          session.refresh_token,

        expires_at:
          session.expires_at,

        user_email:
          session.user_email ??
          null
      },
      resolve
    );
  });
}

function clearSession() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(
      STORAGE_KEYS,
      resolve
    );
  });
}

function tokenExpiresSoon(
  expiresAt
) {
  if (!expiresAt) {
    return true;
  }

  const expiresAtMs =
    Number(expiresAt) * 1000;

  if (
    Number.isNaN(
      expiresAtMs
    )
  ) {
    return true;
  }

  return (
    Date.now() >=
    expiresAtMs -
      5 * 60 * 1000
  );
}

async function parseResponse(
  response
) {
  const contentType =
    response.headers.get(
      "content-type"
    ) || "";

  if (
    contentType.includes(
      "application/json"
    )
  ) {
    try {
      return await response.json();
    } catch {
      return {
        error:
          `GolfOps Live returned invalid JSON (${response.status}).`
      };
    }
  }

  const responseText =
    await response.text();

  if (
    responseText
      .trim()
      .startsWith("<")
  ) {
    return {
      error:
        `GolfOps Live returned an HTML response (${response.status}). Check that the API route exists.`
    };
  }

  return {
    error:
      responseText ||
      `Request failed (${response.status}).`
  };
}

async function refreshSession(
  refreshToken
) {
  if (!refreshToken) {
    throw new Error(
      "GolfOps Live extension is not signed in."
    );
  }

  const response =
    await fetch(
      `${APP_URL}/api/extension/refresh`,
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json"
        },

        body:
          JSON.stringify({
            refresh_token:
              refreshToken
          })
      }
    );

  const result =
    await parseResponse(
      response
    );

  if (
    !response.ok ||
    !result?.access_token ||
    !result?.refresh_token
  ) {
    throw new Error(
      result?.error ||
        `Unable to refresh GolfOps Live session (${response.status}).`
    );
  }

  const previousSession =
    await getStoredSession();

  await saveSession({
    access_token:
      result.access_token,

    refresh_token:
      result.refresh_token,

    expires_at:
      result.expires_at,

    user_email:
      result.user_email ??
      previousSession.user_email ??
      null
  });

  return result;
}

async function getValidAccessToken() {
  let session =
    await getStoredSession();

  if (
    !session.refresh_token
  ) {
    throw new Error(
      "GolfOps Live extension is not signed in."
    );
  }

  if (
    !session.access_token ||
    tokenExpiresSoon(
      session.expires_at
    )
  ) {
    session =
      await refreshSession(
        session.refresh_token
      );
  }

  return {
    accessToken:
      session.access_token,

    refreshToken:
      session.refresh_token
  };
}

async function sendAuthenticatedRequest(
  endpoint,
  payload
) {
  let session =
    await getStoredSession();

  if (
    !session.refresh_token
  ) {
    return {
      ok: false,
      error:
        "GolfOps Live extension is not signed in. Open Extension Options and sign in."
    };
  }

  let accessToken;

  try {
    const validSession =
      await getValidAccessToken();

    accessToken =
      validSession.accessToken;

    session =
      await getStoredSession();
  } catch (error) {
    return {
      ok: false,
      error:
        error instanceof Error
          ? error.message
          : "Unable to refresh GolfOps Live extension login."
    };
  }

  function makeRequest(token) {
    return fetch(
      `${APP_URL}${endpoint}`,
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json",

          Authorization:
            `Bearer ${token}`
        },

        body:
          JSON.stringify(
            payload
          )
      }
    );
  }

  let response =
    await makeRequest(
      accessToken
    );

  if (
    response.status === 401
  ) {
    try {
      const refreshed =
        await refreshSession(
          session.refresh_token
        );

      response =
        await makeRequest(
          refreshed.access_token
        );
    } catch {
      await clearSession();

      return {
        ok: false,
        error:
          "Your GolfOps Live extension session expired. Please sign in again."
      };
    }
  }

  const result =
    await parseResponse(
      response
    );

  if (!response.ok) {
    return {
      ok: false,
      error:
        result?.error ||
        `Import failed (${response.status}).`
    };
  }

  return {
    ok: true,
    ...result
  };
}

function isTrustedPaceSender(
  sender
) {
  const sourceUrl =
    sender?.url ||
    sender?.tab?.url ||
    "";

  try {
    const url =
      new URL(sourceUrl);

    return (
      url.protocol ===
        "https:" &&
      (
        url.hostname ===
          "www.tekgps.net" ||
        url.hostname ===
          "tekgps.net"
      )
    );
  } catch {
    return false;
  }
}

async function fetchSchedulePopReport(
  payload
) {
  try {
    const url =
      new URL(
        payload?.url || ""
      );

    if (
      url.protocol !==
        "https:" ||
      url.hostname !==
        "api.schedulepop.com" ||
      !url.pathname.includes(
        "/printableSchedule"
      )
    ) {
      return {
        ok: false,
        error:
          "Invalid SchedulePop report address."
      };
    }

    url.searchParams.set(
      "format",
      "HTML"
    );

    const response =
      await fetch(
        url.toString(),
        {
          method: "GET",
          cache: "no-store"
        }
      );

    if (!response.ok) {
      return {
        ok: false,
        error:
          `SchedulePop returned ${response.status}.`
      };
    }

    const html =
      await response.text();

    if (
      !html ||
      !html
        .toLowerCase()
        .includes(
          "schedule"
        )
    ) {
      return {
        ok: false,
        error:
          "SchedulePop did not return a printable schedule."
      };
    }

    return {
      ok: true,
      html
    };
  } catch (error) {
    return {
      ok: false,
      error:
        error instanceof Error
          ? error.message
          : "Unable to retrieve SchedulePop."
    };
  }
}

function schedulePopArray(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.results)) return value.results;
  return [];
}

function sanitizeSchedulePopEmployee(value) {
  if (!value || typeof value !== "object") return null;
  return {
    id: Number(value.id),
    firstname: value.firstname || "",
    lastname: value.lastname || "",
    email: value.email || "",
    userStatusTypeName: value.userStatusTypeName || "",
    userDuties: Array.isArray(value.userDuties)
      ? value.userDuties.map((duty) => ({
          id: duty?.id,
          duty: duty?.duty,
          name: duty?.name,
          disabled: duty?.disabled,
          activeDuty: duty?.activeDuty
        }))
      : [],
    userZones: Array.isArray(value.userZones)
      ? value.userZones.map((zone) => ({
          id: zone?.id,
          zone: zone?.zone,
          zoneName: zone?.zoneName,
          enabled: zone?.enabled
        }))
      : []
  };
}

function sanitizeSchedulePopPto(value) {
  if (!value || typeof value !== "object") return null;
  return {
    id: Number(value.id),
    user: Number(value.user),
    firstname: value.firstname || "",
    lastname: value.lastname || "",
    start: value.start || "",
    end: value.end || "",
    allDay: value.allDay !== false,
    approved: value.approved === true,
    isDeleted: value.isDeleted === true,
    status: value.status || "PTO",
    managerNote: value.managerNote || null,
    createDatetime: value.createDatetime || null,
    updateDatetime: value.updateDatetime || null
  };
}

function isActiveSchedulePopEmployee(value) {
  const status = String(value?.userStatusTypeName || "").trim().toLowerCase();
  return !["inactive", "terminated", "disabled"].includes(status);
}

async function schedulePopMapWithConcurrency(values, limit, mapper) {
  const results = new Array(values.length);
  let next = 0;
  async function worker() {
    while (next < values.length) {
      const index = next++;
      results[index] = await mapper(values[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, values.length) }, worker));
  return results;
}

function schedulePopDatePart(value) {
  const match = String(value || "").match(/^(\d{4}-\d{2}-\d{2})/);
  return match?.[1] || "";
}

function schedulePopTimePart(value) {
  const match = String(value || "").match(/(?:T|\s)(\d{1,2}):(\d{2})/);
  return match ? `${match[1].padStart(2, "0")}:${match[2]}` : null;
}

function schedulePopEmployeeName(user, job, userId) {
  const first = String(user?.firstname || job?.firstname || job?.userFirstname || "").trim();
  const last = String(user?.lastname || job?.lastname || job?.userLastname || "").trim();
  const combined = `${first} ${last}`.trim();
  return combined || String(job?.userName || job?.employeeName || `SchedulePop employee ${userId}`);
}

async function collectSchedulePopSchedule(payload) {
  try {
    const authorization = String(payload?.authorization || "").trim();
    const locationId = Number(payload?.locationId);
    const dateStart = String(payload?.dateStart || "");
    const dateEnd = String(payload?.dateEnd || "");

    if (!/^Bearer\s+\S+/i.test(authorization)) {
      throw new Error("SchedulePop authorization was not detected. Refresh SchedulePop and try again.");
    }
    if (!Number.isInteger(locationId) || locationId <= 0) {
      throw new Error("The SchedulePop location could not be identified.");
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStart) || !/^\d{4}-\d{2}-\d{2}$/.test(dateEnd)) {
      throw new Error("The displayed SchedulePop week is invalid.");
    }

    const headers = {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: authorization
    };
    const base = `https://api.schedulepop.com/api/rest/admin/locations/${locationId}`;
    const [scheduleResponse, usersResponse] = await Promise.all([
      fetch(`${base}/scheduleData?scheduleDataTypes=staffView`, {
        method: "POST",
        cache: "no-store",
        headers,
        body: JSON.stringify({ start: dateStart, end: dateEnd })
      }),
      fetch(`${base}/users?active=1&fields=id,firstname,lastname,userStatusTypeName,userDuties,userZones`, {
        method: "GET",
        cache: "no-store",
        headers: { Accept: "application/json", Authorization: authorization }
      })
    ]);

    if (!scheduleResponse.ok) {
      throw new Error(`SchedulePop schedule returned ${scheduleResponse.status}.`);
    }
    if (!usersResponse.ok) {
      throw new Error(`SchedulePop employees returned ${usersResponse.status}.`);
    }

    const scheduleData = await scheduleResponse.json();
    const users = schedulePopArray(await usersResponse.json());
    const usersById = new Map(users.map((user) => [Number(user?.id), user]));
    const shifts = [];
    const userJobsByDay = scheduleData?.userJobsByDay;

    if (!userJobsByDay || typeof userJobsByDay !== "object") {
      throw new Error("SchedulePop did not return the weekly staffing data expected by GolfOps.");
    }

    for (const [rawUserId, jobsByDay] of Object.entries(userJobsByDay)) {
      const userId = Number(rawUserId);
      const user = usersById.get(userId);
      if (!jobsByDay || typeof jobsByDay !== "object") continue;

      for (const [day, dayJobs] of Object.entries(jobsByDay)) {
        if (!Array.isArray(dayJobs)) continue;
        for (const job of dayJobs) {
          if (!job || typeof job !== "object" || job.published === false) continue;
          const shiftDate = schedulePopDatePart(job.startDatetime) || schedulePopDatePart(day);
          if (!shiftDate || shiftDate < dateStart || shiftDate > dateEnd) continue;

          const duty = String(job.dutyName || job.duty?.name || job.shiftName || "").trim() || null;
          const zone = String(job.zoneName || job.zone?.name || "").trim() || null;
          shifts.push({
            employeeName: schedulePopEmployeeName(user, job, userId),
            jobTitle: zone || duty || "SchedulePop",
            shiftDate,
            startTime: schedulePopTimePart(job.startDatetime || job.start),
            endTime: schedulePopTimePart(job.endDatetime || job.end),
            duty,
            zone,
            status: "SCHEDULED",
            notes: String(job.notes || job.note || "").trim() || null
          });
        }
      }
    }

    if (!shifts.length) {
      throw new Error(
        "No published shifts were returned for the displayed week. Confirm the week is published in SchedulePop."
      );
    }

    return {
      ok: true,
      payload: {
        fileName: `SchedulePop direct sync ${dateStart} to ${dateEnd}`,
        dateStart,
        dateEnd,
        shifts
      }
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Unable to collect the SchedulePop schedule."
    };
  }
}

async function collectSchedulePopPto(payload) {
  try {
    const authorization = String(payload?.authorization || "").trim();
    const locationId = Number(payload?.locationId);
    const dateStart = String(payload?.dateStart || "");
    const dateEnd = String(payload?.dateEnd || "");

    if (!/^Bearer\s+\S+/i.test(authorization)) {
      throw new Error("SchedulePop authorization was not detected. Refresh SchedulePop and try again.");
    }
    if (!Number.isInteger(locationId) || locationId <= 0) {
      throw new Error("The SchedulePop location could not be identified.");
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStart) || !/^\d{4}-\d{2}-\d{2}$/.test(dateEnd)) {
      throw new Error("The TEAM PTO date range is invalid.");
    }

    const headers = { Accept: "application/json", Authorization: authorization };
    const fetchJson = async (url) => {
      const response = await fetch(url, { method: "GET", cache: "no-store", headers });
      if (!response.ok) throw new Error(`SchedulePop returned ${response.status}.`);
      return response.json();
    };
    const base = `https://api.schedulepop.com/api/rest/admin/locations/${locationId}`;
    const usersResult = await fetchJson(
      `${base}/users?fields=id,firstname,lastname,email,userStatusTypeName,userDuties,userZones`
    );
    const userList = schedulePopArray(usersResult).filter((user) => Number(user?.id) > 0);
    if (!userList.length) throw new Error("SchedulePop did not return the employee directory.");

    const failures = [];
    const collected = await schedulePopMapWithConcurrency(userList, 4, async (listedUser) => {
      const userId = Number(listedUser.id);
      try {
        const [employeeResult, ptoResult] = await Promise.all([
          fetchJson(`${base}/users/${userId}`),
          fetchJson(
            `${base}/users/${userId}/availabilities?available=0&recurs=0&start=${encodeURIComponent(dateStart)}&end=${encodeURIComponent(dateEnd)}`
          )
        ]);
        const employee = sanitizeSchedulePopEmployee(employeeResult);
        return {
          employee,
          requests: isActiveSchedulePopEmployee(employeeResult)
            ? schedulePopArray(ptoResult).map(sanitizeSchedulePopPto).filter(Boolean)
            : []
        };
      } catch (error) {
        failures.push(
          `${listedUser.firstname || "Employee"} ${listedUser.lastname || userId}: ${
            error instanceof Error ? error.message : "Unable to retrieve PTO."
          }`
        );
        return { employee: sanitizeSchedulePopEmployee(listedUser), requests: [] };
      }
    });

    return {
      ok: true,
      payload: {
        requestId: payload?.requestId || null,
        sourceMode: "full",
        action: "upsert",
        locationId,
        dateStart,
        dateEnd,
        employees: collected.map((item) => item.employee).filter(Boolean),
        requests: collected.flatMap((item) => item.requests),
        complete: failures.length === 0,
        sourceErrors: failures
      }
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Unable to collect SchedulePop PTO."
    };
  }
}

function isTrustedGolfOpsSender(
  sender
) {
  const sourceUrl =
    sender?.url ||
    sender?.tab?.url ||
    "";

  try {
    const url =
      new URL(sourceUrl);

    return (
      url.protocol === "https:" &&
      url.hostname ===
        "golfops-live.vercel.app"
    );
  } catch {
    return false;
  }
}

function isTrustedSchedulePopSender(sender) {
  const sourceUrl = sender?.url || sender?.tab?.url || "";
  try {
    const url = new URL(sourceUrl);
    return url.protocol === "https:" && url.hostname === "app.schedulepop.com";
  } catch {
    return false;
  }
}

function findSchedulePopTabs() {
  return new Promise((resolve) => {
    chrome.tabs.query({ url: ["https://app.schedulepop.com/*"] }, (tabs) => {
      if (chrome.runtime.lastError) {
        resolve([]);
        return;
      }
      resolve(tabs || []);
    });
  });
}

function askSchedulePopTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { type: "START_SCHEDULEPOP_PTO_SYNC" }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, handled: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve({
        handled: true,
        ...(response || { ok: false, error: "SchedulePop did not return a TEAM PTO result." })
      });
    });
  });
}

async function pullSchedulePopPto() {
  const tabs = await findSchedulePopTabs();
  if (!tabs.length) {
    return {
      ok: false,
      error: "Open SchedulePop in Chrome, then try Sync from SchedulePop again."
    };
  }

  for (const tab of tabs) {
    if (!Number.isInteger(tab.id)) continue;
    const result = await askSchedulePopTab(tab.id);
    if (result?.handled) return result;
  }

  return {
    ok: false,
    error: "Reload the open SchedulePop tab so the current GolfOps extension can connect, then try again."
  };
}

function findForeTeesTabs() {
  return new Promise(
    (resolve) => {
      chrome.tabs.query(
        {
          url: [
            "https://web.foretees.com/*",
            "https://*.foretees.com/*"
          ]
        },
        (tabs) => {
          if (
            chrome.runtime.lastError
          ) {
            resolve([]);
            return;
          }

          resolve(tabs || []);
        }
      );
    }
  );
}

function askForeTeesTab(
  tabId,
  message
) {
  return new Promise(
    (resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        message,
        (response) => {
          if (
            chrome.runtime.lastError
          ) {
            resolve(null);
            return;
          }

          resolve(response || null);
        }
      );
    }
  );
}

async function collectOpenForeTeesNotes(
  sheetDate,
  suppliedTabs = null
) {
  const tabs =
    suppliedTabs ||
    await findForeTeesTabs();

  const responses =
    await Promise.all(
      tabs
        .filter(
          (tab) =>
            typeof tab.id === "number"
        )
        .map((tab) =>
          askForeTeesTab(
            tab.id,
            {
              type:
                "COLLECT_FORETEES_TEE_TIME_NOTES",
              sheetDate
            }
          )
        )
    );

  const handledResponses =
    responses.filter(
      (response) =>
        response?.handled
    );
  const successfulResponses =
    handledResponses.filter(
      (response) =>
        response?.ok
    );
  const notesByGroup = new Map();

  for (const response of successfulResponses) {
    for (const note of response.notes || []) {
      const teeTime =
        String(note?.teeTime || "").trim();
      const course =
        String(note?.course || "").trim();
      const text =
        String(note?.note || "").trim();

      if (!teeTime || !course || !text) {
        continue;
      }

      notesByGroup.set(
        `${teeTime}|${course.toLowerCase()}`,
        {
          teeTime,
          course,
          note: text
        }
      );
    }
  }

  return {
    hasMatchingTabs:
      handledResponses.length > 0,
    notes: Array.from(
      notesByGroup.values()
    ),
    complete:
      handledResponses.length > 0 &&
      handledResponses.every(
        (response) =>
          response?.ok &&
          response.complete === true
      ),
    markersFound:
      successfulResponses.reduce(
        (total, response) =>
          total +
          Number(
            response.markersFound || 0
          ),
        0
      ),
    candidatesFound:
      successfulResponses.reduce(
        (total, response) =>
          total +
          Number(
            response.candidatesFound || 0
          ),
        0
      ),
    documentsScanned:
      successfulResponses.reduce(
        (total, response) =>
          total +
          Number(
            response.documentsScanned || 0
          ),
        0
      )
  };
}

async function sendTeeSheetWithOpenNotes(
  payload
) {
  const openTabCapture =
    await collectOpenForeTeesNotes(
      payload?.sheetDate
    );

  const enhancedPayload =
    openTabCapture.hasMatchingTabs
      ? {
          ...payload,
          teeTimeNotes:
            openTabCapture.notes,
          teeTimeNotesComplete:
            openTabCapture.complete
        }
      : payload;

  return sendAuthenticatedRequest(
    "/api/import/extension",
    enhancedPayload
  );
}

async function pullForeTeesTeeSheet(
  sheetDate
) {
  const tabs =
    await findForeTeesTabs();

  if (tabs.length === 0) {
    return {
      ok: false,
      error:
        "Open the matching live tee sheet in ForeTees on this computer, then try again."
    };
  }

  const teeTimeNoteCapture =
    await collectOpenForeTeesNotes(
      sheetDate,
      tabs
    );

  for (const tab of tabs) {
    if (
      typeof tab.id !== "number"
    ) {
      continue;
    }

    const result =
      await askForeTeesTab(
        tab.id,
        {
          type:
            "PULL_FORETEES_TEE_SHEET",
          sheetDate,
          teeTimeNoteCapture:
            teeTimeNoteCapture
              .hasMatchingTabs
              ? teeTimeNoteCapture
              : null
        }
      );

    if (result?.handled) {
      return result;
    }
  }

  return {
    ok: false,
    error:
      "Open the live ForeTees tee sheet for the selected GolfOps date, then try again."
  };
}

const GOLFGENIUS_DIRECTORIES = [
  {
    ggid: "qsnypb",
    type: "CLINIC",
    url: "https://www.golfgenius.com/ggid/qsnypb"
  },
  {
    ggid: "cghk44",
    type: "FITTING",
    url: "https://www.golfgenius.com/ggid/cghk44"
  }
];

const GOLFGENIUS_ALARM =
  "golfgenius-daily-sync";

function golfGeniusStorageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => resolve(result || {}));
  });
}

function golfGeniusStorageSet(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, resolve);
  });
}

function golfGeniusCreateTab(url) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url, active: false }, (tab) => {
      if (chrome.runtime.lastError || !Number.isInteger(tab?.id)) {
        reject(new Error(chrome.runtime.lastError?.message || "Unable to open Golf Genius in the background."));
        return;
      }
      resolve(tab.id);
    });
  });
}

function golfGeniusCloseTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.remove(tabId, () => {
      void chrome.runtime.lastError;
      resolve();
    });
  });
}

function golfGeniusNavigate(tabId, url) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Golf Genius took too long to load."));
    }, 30000);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(resolve, 1200);
    }

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.update(tabId, { url, active: false }, () => {
      if (!chrome.runtime.lastError) return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error(chrome.runtime.lastError.message));
    });
  });
}

async function golfGeniusAskTab(tabId, type) {
  let lastError = null;
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const result = await new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { type }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, unavailable: true, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { ok: false, error: "Golf Genius returned no page data." });
      });
    });
    if (!result.unavailable) return result;
    lastError = result.error;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return { ok: false, error: lastError || "The Golf Genius page reader did not load." };
}

function golfGeniusDateInRange(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ""))) return false;
  const eventDate = new Date(`${value}T12:00:00`);
  const earliest = new Date();
  earliest.setHours(0, 0, 0, 0);
  const latest = new Date(earliest);
  latest.setDate(latest.getDate() + 30);
  return eventDate >= earliest && eventDate <= latest;
}

async function collectGolfGeniusPrograms(trigger = "MANUAL") {
  const session = await getStoredSession();
  if (!session.refresh_token) {
    return { ok: false, error: "GolfOps Live extension is not signed in. Open Extension Options and sign in." };
  }

  let tabId = null;
  const events = [];
  const directories = [];

  try {
    tabId = await golfGeniusCreateTab("about:blank");

    for (const directory of GOLFGENIUS_DIRECTORIES) {
      try {
        await golfGeniusNavigate(tabId, directory.url);
        let parsedDirectory = await golfGeniusAskTab(tabId, "GOLFGENIUS_PARSE_DIRECTORY");
        if (!parsedDirectory?.ok && parsedDirectory?.frameUrl) {
          await golfGeniusNavigate(tabId, parsedDirectory.frameUrl);
          parsedDirectory = await golfGeniusAskTab(tabId, "GOLFGENIUS_PARSE_DIRECTORY");
        }
        if (!parsedDirectory?.ok) throw new Error(parsedDirectory?.error || "The directory could not be read.");

        const directoryEvents = Array.isArray(parsedDirectory.events)
          ? parsedDirectory.events.filter((event) => golfGeniusDateInRange(event?.date)).slice(0, 60)
          : [];

        for (const listedEvent of directoryEvents) {
          const event = {
            ...listedEvent,
            directoryGgid: directory.ggid,
            type: directory.type,
            participants: []
          };

          try {
            await golfGeniusNavigate(tabId, listedEvent.sourceUrl);
            const eventDetails = await golfGeniusAskTab(tabId, "GOLFGENIUS_PARSE_EVENT");
            if (eventDetails?.ok) {
              event.startTime = eventDetails.startTime || null;
              event.endTime = eventDetails.endTime || null;
              event.location = eventDetails.location || event.location || null;
              event.sourceText = eventDetails.sourceText || event.sourceText || null;

              if (eventDetails.participantUrl) {
                await golfGeniusNavigate(tabId, eventDetails.participantUrl);
                const roster = await golfGeniusAskTab(tabId, "GOLFGENIUS_PARSE_PARTICIPANTS");
                if (roster?.ok && Array.isArray(roster.participants)) {
                  event.participants = roster.participants;
                }
              }
            }
          } catch (error) {
            event.detailError = error instanceof Error ? error.message : "Event details could not be read.";
          }

          events.push(event);
        }

        directories.push({ ggid: directory.ggid, type: directory.type, complete: true, error: null });
      } catch (error) {
        directories.push({
          ggid: directory.ggid,
          type: directory.type,
          complete: false,
          error: error instanceof Error ? error.message : "The Golf Genius directory could not be read."
        });
      }
    }
  } finally {
    if (Number.isInteger(tabId)) await golfGeniusCloseTab(tabId);
  }

  const result = await sendAuthenticatedRequest("/api/golfgenius/import", {
    trigger,
    events,
    directories
  });

  await golfGeniusStorageSet({
    golfgenius_last_attempt_at: new Date().toISOString(),
    golfgenius_last_result: result
  });

  return result;
}

function scheduleNextGolfGeniusSync(delayMinutes = null) {
  const when = new Date();
  if (typeof delayMinutes === "number") {
    when.setTime(Date.now() + delayMinutes * 60000);
  } else {
    when.setHours(5, 15, 0, 0);
    if (when.getTime() <= Date.now()) when.setDate(when.getDate() + 1);
  }
  chrome.alarms.create(GOLFGENIUS_ALARM, { when: when.getTime() });
}

chrome.runtime.onInstalled.addListener(() => scheduleNextGolfGeniusSync(5));
chrome.runtime.onStartup.addListener(async () => {
  const stored = await golfGeniusStorageGet(["golfgenius_last_attempt_at"]);
  const lastAttempt = Date.parse(stored.golfgenius_last_attempt_at || "");
  const stale = !Number.isFinite(lastAttempt) || Date.now() - lastAttempt > 20 * 60 * 60 * 1000;
  scheduleNextGolfGeniusSync(stale ? 3 : null);
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== GOLFGENIUS_ALARM) return;
  collectGolfGeniusPrograms("DAILY").catch(() => undefined).finally(() => scheduleNextGolfGeniusSync());
});

chrome.runtime.onMessage.addListener(
  (
    message,
    sender,
    sendResponse
  ) => {
    let operation = null;

    if (
      message?.type ===
      "SEND_TEE_SHEET"
    ) {
      operation =
        sendTeeSheetWithOpenNotes(
          message.payload
        );
    } else if (
      message?.type ===
      "PULL_FORETEES_TEE_SHEET"
    ) {
      if (
        !isTrustedGolfOpsSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "The manual ForeTees refresh request was rejected."
          });
      } else {
        operation =
          pullForeTeesTeeSheet(
            message.sheetDate
          );
      }
    } else if (
      message?.type ===
      "PULL_GOLFGENIUS_PROGRAMS"
    ) {
      if (
        !isTrustedGolfOpsSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "The Golf Genius sync request was rejected."
          });
      } else {
        operation =
          collectGolfGeniusPrograms("MANUAL");
      }
    } else if (
      message?.type ===
      "SEND_LESSONS"
    ) {
      operation =
        sendAuthenticatedRequest(
          "/api/lessons/import",
          message.payload
        );
    } else if (
      message?.type ===
      "SEND_SCHEDULEPOP"
    ) {
      operation =
        sendAuthenticatedRequest(
          "/api/schedulepop/extension",
          message.payload
        );
    } else if (
      message?.type ===
      "SEND_SCHEDULEPOP_PTO"
    ) {
      if (
        !isTrustedSchedulePopSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "TEAM PTO was rejected because it did not originate from SchedulePop."
          });
      } else {
        operation =
          sendAuthenticatedRequest(
            "/api/schedulepop/pto/extension",
            message.payload
          );
      }
    } else if (
      message?.type ===
      "COLLECT_SCHEDULEPOP_SCHEDULE"
    ) {
      if (
        !isTrustedSchedulePopSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "SchedulePop schedule collection was rejected because it did not originate from SchedulePop."
          });
      } else {
        operation =
          collectSchedulePopSchedule(
            message.payload
          );
      }
    } else if (
      message?.type ===
      "COLLECT_SCHEDULEPOP_PTO"
    ) {
      if (
        !isTrustedSchedulePopSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "SchedulePop PTO collection was rejected because it did not originate from SchedulePop."
          });
      } else {
        operation =
          collectSchedulePopPto(
            message.payload
          );
      }
    } else if (
      message?.type ===
      "PULL_SCHEDULEPOP_PTO"
    ) {
      if (
        !isTrustedGolfOpsSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "The TEAM PTO sync request was rejected."
          });
      } else {
        operation =
          pullSchedulePopPto();
      }
    } else if (
      message?.type ===
      "SEND_FORETEES_BAG_MEMBER"
    ) {
      operation =
        sendAuthenticatedRequest(
          "/api/bag-finder/foretees-sync",
          message.payload
        );
    } else if (
      message?.type ===
      "SEND_PACE_STATUS"
    ) {
      if (
        !isTrustedPaceSender(
          sender
        )
      ) {
        operation =
          Promise.resolve({
            ok: false,
            error:
              "PACE update was rejected because it did not originate from PACE."
          });
      } else {
        operation =
          sendAuthenticatedRequest(
            "/api/pace/extension",
            message.payload
          );
      }
    } else if (
      message?.type ===
      "FETCH_SCHEDULEPOP_REPORT"
    ) {
      operation =
        fetchSchedulePopReport(
          message.payload
        );
    } else if (
      message?.type ===
      "CHECK_AUTH"
    ) {
      operation =
        getStoredSession()
          .then(
            (session) => ({
              ok: true,

              signedIn:
                Boolean(
                  session
                    .refresh_token
                ),

              user_email:
                session.user_email ||
                null,

              expires_at:
                session.expires_at ||
                null
            })
          );
    }

    if (!operation) {
      return false;
    }

    operation
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          ok: false,

          error:
            error instanceof Error
              ? error.message
              : "Unknown extension error."
        });
      });

    return true;
  }
);

/*
  Detect SchedulePop printable
  schedule requests directly
  through Chrome.
*/

chrome.webRequest
  .onBeforeRequest
  .addListener(
    (details) => {
      if (
        details.tabId < 0
      ) {
        return;
      }

      chrome.tabs.sendMessage(
        details.tabId,
        {
          type:
            "SCHEDULEPOP_REPORT_DETECTED",

          url:
            details.url
        },
        () => {
          /*
            Ignore pages that do not
            contain the SchedulePop
            content script.
          */

          void chrome.runtime
            .lastError;
        }
      );
    },
    {
      urls: [
        "https://api.schedulepop.com/api/rest/admin/locations/*/printableSchedule*"
      ]
    }
  );
